#ifndef UWB_PARSER_H
#define UWB_PARSER_H

#include <stdlib.h>
#include <stdbool.h>

void uwb_parser_init();
bool uwb_parser_check_data();
void uwb_test_range();

#endif
