#ifndef APP_SOUND_H
#define APP_SOUND_H


void play_letter(char l);
void setup_player(void);

#endif